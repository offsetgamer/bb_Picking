Credit goes to original author.  See below.

Removed Warmenu
Added UI prompts
Modified cooldown
added support for vorp-progressbar
added cancarry checks for received items

# vorp_lumberjack
Used some code from lumberjack resource for these changes.

RESOURCE CREATED FOR THE Bluebird redM server -
# Implemented by Chommpe


VERSION 1.0 27/01/2021.


# bb_picking

- For picking ( could be used for other jobs )

### what to do next
- Nothing
 
Add item.sql to your database.

Add this to your server.cfg
```
ensure progress_bar
ensure bb_picking
```
 
